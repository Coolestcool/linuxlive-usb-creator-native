#define VERSION 4.07
#define VERSION_STR "4.07"
#define VERSION_MAJOR 4
#define VERSION_MINOR 7
#define YEAR 2013
#define YEAR_STR "2013"
